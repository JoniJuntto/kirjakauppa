package com.example.kirjakauppa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KirjakauppaApplicationTests {

	@Test
	void contextLoads() {
	}

}
